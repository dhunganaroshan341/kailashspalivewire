<?php

namespace App\Filament\Resources\BrandImagesResource\Pages;

use App\Filament\Resources\BrandImagesResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateBrandImages extends CreateRecord
{
    protected static string $resource = BrandImagesResource::class;
}
