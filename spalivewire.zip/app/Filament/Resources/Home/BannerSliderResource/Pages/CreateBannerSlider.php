<?php

namespace App\Filament\Resources\Home\BannerSliderResource\Pages;

use App\Filament\Resources\Home\BannerSliderResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateBannerSlider extends CreateRecord
{
    protected static string $resource = BannerSliderResource::class;
}
