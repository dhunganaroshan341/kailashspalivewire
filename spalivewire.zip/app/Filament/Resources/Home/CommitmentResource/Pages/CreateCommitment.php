<?php

namespace App\Filament\Resources\Home\CommitmentResource\Pages;

use App\Filament\Resources\Home\CommitmentResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateCommitment extends CreateRecord
{
    protected static string $resource = CommitmentResource::class;
}
