<?php

namespace App\Filament\Resources\Home\TestimonialSectionResource\Pages;

use App\Filament\Resources\Home\TestimonialSectionResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateTestimonialSection extends CreateRecord
{
    protected static string $resource = TestimonialSectionResource::class;
}
