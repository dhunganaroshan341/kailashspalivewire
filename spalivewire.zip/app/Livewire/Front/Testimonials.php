<?php

namespace App\Livewire\Front;

use Livewire\Component;

class Testimonials extends Component
{
    public function render()
    {
        return view('livewire.front.testimonials');
    }
}
