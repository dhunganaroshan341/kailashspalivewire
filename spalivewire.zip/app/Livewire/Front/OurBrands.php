<?php

namespace App\Livewire\Front;

use Livewire\Component;

class OurBrands extends Component
{
    public function render()
    {
        return view('livewire.front.our-brands');
    }
}
