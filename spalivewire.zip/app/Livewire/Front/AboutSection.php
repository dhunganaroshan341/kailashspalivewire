<?php

namespace App\Livewire\Front;

use Livewire\Component;

class AboutSection extends Component
{
    public function render()
    {
        return view('livewire.front.about-section');
    }
}
