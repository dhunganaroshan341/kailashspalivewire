{{-- <form wire:submit.prevent="submit" class="contact-form">
    <div class="form">
        <div>
            <div class="form-body">
                <div class="grid-show-wrapper">
                    <div class="control">
                        <label class="label">
                            Name
                            <span class="required">*</span>
                        </label>
                        <input class="input" type="text" placeholder="Your Name" wire:model="name">
                    </div>

                    <div class="control">
                        <label class="label">
                            Email
                            <span class="required">*</span>
                        </label>
                        <input class="input" type="email" placeholder="Your Email" wire:model="email">
                    </div>
                    <div class="control">
                        <label class="label">
                            Phone
                            <span class="required">*</span>
                        </label>
                        <input class="input" type="text" placeholder="Phone Number" wire:model="phone">
                    </div>

                    <div class="control">
                        <label class="label">
                            Subject
                            <span class="required">*</span>
                        </label>
                        <input class="input" type="text" placeholder="Subject" wire:model="subject">
                    </div>
                </div>
                <div class="message-wrapper">
                    <label class="label">Message <span class="required">*</span></label>
                    <textarea class="textarea" placeholder="Message" wire:model="message"></textarea>
                </div>
                <div class="btn-submit">
                    <button type="submit" class="subBtn text-hov">
                        SUBMIT
                    </button>
                </div>
            </div>
        </div>
    </div>
</form> --}}
